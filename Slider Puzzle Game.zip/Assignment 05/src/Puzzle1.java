import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.*;

import java.util.*;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Pos;
import java.lang.reflect.Array;

import javafx.event.*;
import java.util.Random;
import javafx.geometry.Pos;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Puzzle1 extends Pane {
    TextField time=new TextField();
    Timeline updateTimer;
    int timer;
    public Puzzle1() {

        Pane innerPane = new Pane();
        Label label2 = new Label("Time :");
        label2.relocate(10, 50);
        label2.setPrefSize(50, 30);
        innerPane.getChildren().add(label2);
        TextField time=new TextField("00:00");
        time.relocate(50, 50);
        time.setPrefSize(126, 30);


        time.setEditable(false);
        //time.relocate(832, 397);
        //time.setPrefSize(126, 30);
        timer=0;
        updateTimer=new Timeline(new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                timer++;
                System.out.println(timer);
                time.setText((String.format("%02d",timer/60)+":"+String.format("%02d",timer%60)));
            }
        }));

        updateTimer.setCycleCount(Timeline.INDEFINITE);
        Button Button2 = new Button("Start");
        Button2.setStyle("-fx-base:DARKGREEN;");

        Button2.relocate(10, 10);
        Button2.setPrefSize(186, 30);
        Button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(Button2.getText()=="Start"){
                    //fruitList.setDisable(true);
                    updateTimer.play();
                    Button2.setText("Stop");
                    Button2.setStyle("-fx-base:DARKRED;");
                }

                else if (Button2.getText()=="Stop"){
                    updateTimer.stop();
                    //fruitList.setDisable(false);
                    timer=0;
                    time.setText((String.format("%02d",timer/60)+":"+String.format("%02d",timer%60)));
                    Button2.setText("Start");
                    Button2.setStyle("-fx-base:DARKGREEN;");
                }
            }

        });
        innerPane.getChildren().addAll(Button2,time);
        getChildren().add(innerPane);
    }
}