import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.*;
import javafx.scene.*;
import java.util.*;
import javafx.geometry.*;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Pos;
import java.lang.reflect.Array;

import javafx.event.*;
import java.util.Random;

public class Puzzle extends Application {
    ListView<String> fruitList;
    String[] choice = {"Pets", "Scenery", "Lego", "Numbers"};
    TextField time=new TextField();
    Timeline updateTimer;
    int timer;
    Button[][] buttons;
    Image[][] images;
    int bk1,bk2;

    public void start(Stage primaryStage) {

        int[][] a={{1,2,3,4},
                {5,6,7,8},
                {9,10,11,12},
                {13,14,15,16}};
        Image blank;
        String name = null;
        Pane aPane=new Pane();
        GridPane bPane = new GridPane();

        bPane.setPadding(new Insets(10, 10, 10, 10));
        bPane.setHgap(1);
        bPane.setVgap(1);
        buttons=new Button[4][4];
        images=new Image[4][4];
        blank=new Image(getClass().getResourceAsStream("BLANK.png"));

        for (int row=0; row<4; row++)
            for (int col=0; col<4; col++) {

                buttons[row][col]= new Button();
                //buttons[row][col].relocate(188*col,188*row);
                /*buttons[row][col].setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {

                    }

                });*/
                //buttons[row][col].setPrefSize(187,187);


                images[row][col]=new Image(getClass().getResourceAsStream("BLANK.png"));

                buttons[row][col].setGraphic(new ImageView(images[row][col]));
                /*buttons[row][col].setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {

                        for (int row = 0; row < 4; row++)
                            for (int col = 0; col < 4; col++) {
                                if (buttons[row+1][col]==buttons[bk1][bk2]){
                                    buttons[bk1][bk2]=buttons[row][col];
                                }
                                else if (buttons[row-1][col]==buttons[bk1][bk2]){
                                    swap(buttons,row,col,bk1,bk2);
                                }
                                else if (buttons[row][col+1]==buttons[bk1][bk2]){
                                    swap(buttons,row,col,bk1,bk2);
                                }
                                else if (buttons[row][col-1]==buttons[bk1][bk2]){
                                    swap(buttons,row,col,bk1,bk2);
                                }
                            }
                    }
                });*/
                /*for(int u=0;u<images.length;u++){
                    for(int i=0;i<images[u].length;i++){
                        int u1=(int)(Math.random()*images.length);
                        int i1=(int)(Math.random()*images[u].length);
                        Button newb=buttons[u][i];
                        buttons[u][i]=buttons[u1][i1];
                        buttons[u1][i1]=newb;

                    }

                }
                /*for(int u=0;u<buttons.length;u++){
                    for(int i=0;i<buttons[u].length;i++){
                        buttons[row][col]=buttons[u][i];

                    }
                }*/
                //images[r1][c1]=new Image(getClass().getResourceAsStream("BLANK.png"));
                //bPane.getChildren().add(buttons[row][col],0,0);
                bPane.add(buttons[row][col],row,col);

                buttons[row][col].setPadding(new Insets(0, 0, 0, 0));
                // Make the buttons bigger than we want. They will be
                // re-sized to fit within the shrunken pane.

            }
        //aPane.getChildren().add(bPane);
        int bk1=(int)(Math.random()*4);
        int bk2=(int)(Math.random()*4);
        buttons[bk1][bk2].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
        for(int u=0;u<images.length;u++) {
            for (int i = 0; i < images[u].length; i++) {
                int u1 = (int) (Math.random() * 4);
                int i1 = (int) (Math.random() * images[u].length);
                Button newb = buttons[u][i];
                buttons[u][i] = buttons[u1][i1];
                buttons[u1][i1] = newb;

            }
        }



        Label Label1 = new Label();
        //Label1.relocate(772, 0);
        //Label1.setPrefSize(187, 187);
        //aPane.getChildren().add(Label1);
        bPane.add(Label1,4,0);
        Label1.setPadding(new Insets(0, 0, 0, 10));
        fruitList = new ListView<String>();
        fruitList.setItems(FXCollections.observableArrayList(choice));
        //fruitList.relocate(772, 197);
        //fruitList.setPrefWidth(187);
        //fruitList.setPrefHeight(140);
        fruitList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                Random random=new Random(System.currentTimeMillis());
                int m=0;
                int n=0;

                if(fruitList.getSelectionModel().getSelectedItem()== null){
                    //System.out.println("BLANK.png");
                    Label1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {

                            images[row][col]=new Image(getClass().getResourceAsStream("BLANK.png"));
                            buttons[row][col].setGraphic(new ImageView(images[row][col]));

                        }
                    }


                }
                else if (fruitList.getSelectionModel().getSelectedItem()=="Pets"){
                    int bk1=(int)(Math.random()*4);
                    int bk2=(int)(Math.random()*4);
                    //System.out.println("Pets_");
                    Label1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Pets_Thumbnail.png"))));

                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {
                            images[row][col]=new Image(getClass().getResourceAsStream("Pets_"+row+col+".png"));

                            buttons[row][col].setGraphic(new ImageView(images[row][col]));
                            /*for(int u=0;u<10;u++){
                                for(int i=0;i<images[u].length;i++){
                                    int u1=(int)(Math.random()*4);
                                    int i1=(int)(Math.random()*images[u].length);
                                    Button newb=buttons[u][i];
                                    buttons[u][i]=buttons[u1][i1];
                                    buttons[u1][i1]=newb;

                                }
                            }
                            for(int u=0;u<106;u++){
                                for(int i=0;i<images[u].length;i++){
                                    buttons[row][col]=buttons[u][i];
                                }

                            }*/

                        }
                    }

                    buttons[bk1][bk2].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));

                    for(int u=0;u<images.length;u++) {
                        for (int i = 0; i < images[u].length; i++) {
                            int u1 = (int) (Math.random() * 4);
                            int i1 = (int) (Math.random() * images[u].length);
                            Button newb = buttons[u][i];
                            buttons[u][i] = buttons[u1][i1];
                            buttons[u1][i1] = newb;

                        }
                    }

                }
                else if (fruitList.getSelectionModel().getSelectedItem()=="Scenery"){
                    //System.out.println("Scenery_");
                    Label1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Scenery_Thumbnail.png"))));
                    int bk1=(int)(Math.random()*4);
                    int bk2=(int)(Math.random()*4);
                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {
                            images[row][col]=new Image(getClass().getResourceAsStream("Scenery_"+row+col+".png"));
                            buttons[row][col].setGraphic(new ImageView(images[row][col]));
                            buttons[row][col].setOnMouseClicked(new EventHandler<MouseEvent>() {
                                @Override
                                public void handle(MouseEvent event) {

                                    for (int row = 0; row < 4; row++)
                                        for (int col = 0; col < 4; col++) {
                                            if (buttons[row+1][col]==buttons[bk1][bk2]&&buttons[row-1][col]==buttons[bk1][bk2]&&buttons[row][col+1]==buttons[bk1][bk2]&&buttons[row][col-1]==buttons[bk1][bk2]){
                                                swap(buttons,row,col,bk1,bk2);
                                            }

                                        }
                                }
                            });

                        }
                    }

                    buttons[bk1][bk2].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    for(int u=0;u<images.length;u++) {
                        for (int i = 0; i < images[u].length; i++) {
                            int u1 = (int) (Math.random() * 4);
                            int i1 = (int) (Math.random() * images[u].length);
                            Button newb = buttons[u][i];
                            buttons[u][i] = buttons[u1][i1];
                            buttons[u1][i1] = newb;

                        }
                    }

                }
                else if (fruitList.getSelectionModel().getSelectedItem()=="Lego"){
                    //System.out.println("Lego_");
                    int bk1=(int)(Math.random()*4);
                    int bk2=(int)(Math.random()*4);
                    Label1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Lego_Thumbnail.png"))));
                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {
                            images[row][col]=new Image(getClass().getResourceAsStream("Lego_"+row+col+".png"));
                            buttons[row][col].setGraphic(new ImageView(images[row][col]));
                        }
                    }

                    buttons[bk1][bk2].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    for(int u=0;u<images.length;u++) {
                        for (int i = 0; i < images[u].length; i++) {
                            int u1 = (int) (Math.random() * 4);
                            int i1 = (int) (Math.random() * images[u].length);
                            Button newb = buttons[u][i];
                            buttons[u][i] = buttons[u1][i1];
                            buttons[u1][i1] = newb;

                        }
                    }
                }
                else if (fruitList.getSelectionModel().getSelectedItem()=="Numbers"){
                    int bk1=(int)(Math.random()*4);
                    int bk2=(int)(Math.random()*4);
                    Label1.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("Numbers_Thumbnail.png"))));
                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {
                            images[row][col]=new Image(getClass().getResourceAsStream("Numbers_"+row+col+".png"));
                            buttons[row][col].setGraphic(new ImageView(images[row][col]));
                        }
                    }

                    buttons[bk1][bk2].setGraphic(new ImageView(new Image(getClass().getResourceAsStream("BLANK.png"))));
                    for(int u=0;u<images.length;u++) {
                        for (int i = 0; i < images[u].length; i++) {
                            int u1 = (int) (Math.random() * 4);
                            int i1 = (int) (Math.random() * images[u].length);
                            Button newb = buttons[u][i];
                            buttons[u][i] = buttons[u1][i1];
                            buttons[u1][i1] = newb;

                        }
                    }
                }
            }
        });
        //aPane.getChildren().add(fruitList);
        bPane.add(fruitList,4,1);
        fruitList.setPadding(new Insets(10, 0, 0, 10));
        //Label label2 = new Label("Time:");
        //bPane.add(label2,4,3);
        //label1.relocate(772, 397);
        //label1.setPrefSize(50, 30);
        //time=new TextField("00:00");
        //time.setEditable(false);
        Pane innerPane = new Pane();
        Label label2 = new Label("Time :");
        label2.relocate(10, 50);
        label2.setPrefSize(50, 30);
        TextField time=new TextField("0:00");
        time.relocate(50, 50);
        time.setPrefSize(126, 30);


        time.setEditable(false);
        //time.relocate(832, 397);
        //time.setPrefSize(126, 30);
        timer=0;
        updateTimer=new Timeline(new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                timer++;
                System.out.println(timer);
                time.setText((timer/60+":"+String.format("%02d",timer%60)));
            }
        }));

        updateTimer.setCycleCount(Timeline.INDEFINITE);
        Button Button2 = new Button("Start");
        Button2.setStyle("-fx-base:DARKGREEN;");

        Button2.relocate(10, 10);
        Button2.setPrefSize(186, 30);
        Button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(Button2.getText()=="Start"){
                    fruitList.setDisable(true);
                    Label1.setDisable(true);
                    updateTimer.play();
                    Button2.setText("Stop");
                    Button2.setStyle("-fx-base:DARKRED;");
                }

                else if (Button2.getText()=="Stop"){
                    updateTimer.stop();
                    Label1.setDisable(false);
                    for (int row=0; row<4; row++){
                        for (int col=0; col<4; col++) {

                            images[row][col]=new Image(getClass().getResourceAsStream("BLANK.png"));
                            buttons[row][col].setGraphic(new ImageView(images[row][col]));

                        }
                    }
                    fruitList.setDisable(false);
                    timer=0;
                    time.setText((String.format("%02d",timer/60)+":"+String.format("%02d",timer%60)));
                    Button2.setText("Start");
                    Button2.setStyle("-fx-base:DARKGREEN;");
                }
            }

        });
        innerPane.getChildren().addAll(label2,Button2,time);
        //getChildren().add(innerPane);
        //Puzzle1 aaa=new Puzzle1();
        bPane.add(innerPane,4,2);
        innerPane.setPadding(new Insets(0, 0, 0, 0));

        /*time.setEditable(false);
        //time.relocate(832, 397);
        //time.setPrefSize(126, 30);
        timer=0;
        updateTimer=new Timeline(new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                timer++;
                System.out.println(timer);
                time.setText((String.format("%02d",timer/60)+":"+String.format("%02d",timer%60)));
            }
        }));

        updateTimer.setCycleCount(Timeline.INDEFINITE);
        Button Button2 = new Button("Start");
        Button2.setStyle("-fx-base:DARKGREEN;");
        fruitList.setPadding(new Insets(0, 0, 0, 10));
        //Button2.relocate(772, 357);
        //Button2.setPrefSize(186, 30);
        Button2.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(Button2.getText()=="Start"){
                    fruitList.setDisable(true);
                    updateTimer.play();
                    Button2.setText("Stop");
                    Button2.setStyle("-fx-base:DARKRED;");
                }

                else if (Button2.getText()=="Stop"){
                    updateTimer.stop();
                    fruitList.setDisable(false);
                    timer=0;
                    time.setText((String.format("%02d",timer/60)+":"+String.format("%02d",timer%60)));
                    Button2.setText("Start");
                    Button2.setStyle("-fx-base:DARKGREEN;");
                }
            }

        });

        //aPane.getChildren().addAll(label1,Button2,time);
        bPane.add(Button2,4,2);
        Button2.setMinHeight(30);
        Button2.setMinWidth(186);
*/
        //bPane.add(time,4,3);
        //time.setPadding(new Insets(0, 0, 0, 50));


        /*
        GridPane bPane = new GridPane();
        bPane.setPadding(new Insets(10, 207, 10, 10));
        bPane.setHgap(1);
        bPane.setVgap(1);
        for (int row=1,k=0; row<5; row++)
            for (int col=1; col<5; col++,k++) {

                Button b = new Button();

                // Make the buttons bigger than we want. They will be
                // re-sized to fit within the shrunken pane.
                b.setPrefWidth(187);
                b.setPrefHeight(187);


                bPane.add(b, col, row);
            }

        aPane.getChildren().add(bPane);*/


        primaryStage.setTitle("Simple GridPane Example");
        primaryStage.setScene(new Scene(bPane, 968,770));
        primaryStage.show();
    }


    public void swap(Button[][] buttons, int i0, int j0, int i1, int j1){
        Button temp = buttons[i0][j0];
        buttons[i0][j0] = buttons[i1][j1];
        buttons[i1][j1] = temp;
    }

    //This function Randomizes the Buttons

/*
    public void update(){
        for (int row=0; row<4; row++)
            for (int col=0; col<4; col++) {
                buttons[row][col].setGraphic(new ImageView(images[row][col]));
            }
    }*/


    public void update(){
        for (int row=0; row<4; row++){
            for (int col=0; col<4; col++) {
                buttons[row][col].setGraphic(new ImageView(images[row][col]));
    }}}
    public static void main(String[] args){
        launch(args);
    }
}